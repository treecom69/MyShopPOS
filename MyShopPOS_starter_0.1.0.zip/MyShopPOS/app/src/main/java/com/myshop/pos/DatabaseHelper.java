package com.myshop.pos;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context c) { super(c, "myshop_pos.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)");
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT, barcode TEXT, name TEXT NOT NULL, category_id INTEGER, unit TEXT DEFAULT 'ชิ้น', cost REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0, stock REAL NOT NULL DEFAULT 0, min_stock REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, subtotal REAL NOT NULL, discount REAL NOT NULL DEFAULT 0, total REAL NOT NULL, payment_method TEXT NOT NULL, paid REAL NOT NULL, change_amount REAL NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER NOT NULL, product_name TEXT NOT NULL, qty REAL NOT NULL, cost REAL NOT NULL, price REAL NOT NULL, line_total REAL NOT NULL)");
        db.execSQL("CREATE TABLE stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, movement_type TEXT NOT NULL, qty REAL NOT NULL, note TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)");
        String[] cats = {"เครื่องดื่ม","ขนม","ของใช้","อาหารแห้ง","อื่น ๆ"};
        for (String c : cats) { ContentValues v=new ContentValues(); v.put("name",c); db.insert("categories",null,v); }
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public long addProduct(String sku, String barcode, String name, String category, String unit, double cost, double price, double stock) {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues v=new ContentValues();
        v.put("sku",sku); v.put("barcode",barcode); v.put("name",name); v.put("category_id",categoryId(category));
        v.put("unit",unit); v.put("cost",cost); v.put("price",price); v.put("stock",stock);
        long id=db.insert("products",null,v);
        if(id>0 && stock>0) movement(db,id,"IN",stock,"ยอดตั้งต้น");
        return id;
    }
    private long categoryId(String name) {
        SQLiteDatabase db=getWritableDatabase();
        Cursor c=db.rawQuery("SELECT id FROM categories WHERE name=?",new String[]{name});
        if(c.moveToFirst()){long id=c.getLong(0);c.close();return id;} c.close();
        ContentValues v=new ContentValues();v.put("name",name);return db.insert("categories",null,v);
    }
    private void movement(SQLiteDatabase db,long pid,String type,double qty,String note){
        ContentValues m=new ContentValues();m.put("product_id",pid);m.put("movement_type",type);m.put("qty",qty);m.put("note",note);db.insert("stock_movements",null,m);
    }
    public Cursor products(String q) {
        return getReadableDatabase().rawQuery(
            "SELECT p.id,p.name,p.sku,p.barcode,p.unit,p.cost,p.price,p.stock,COALESCE(c.name,'อื่น ๆ') " +
            "FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1 AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?) ORDER BY p.name",
            new String[]{"%"+q+"%","%"+q+"%","%"+q+"%"});
    }
    public void adjustStock(long id,double qty,String note) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { db.execSQL("UPDATE products SET stock=stock+? WHERE id=?",new Object[]{qty,id}); movement(db,id,qty>=0?"IN":"ADJUST",qty,note);db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }
    public void checkout(Map<Long,Integer> cart,String method,double paid) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            double total=0;
            for(Map.Entry<Long,Integer> e:cart.entrySet()){
                Cursor c=db.rawQuery("SELECT price,stock FROM products WHERE id=?",new String[]{String.valueOf(e.getKey())});
                if(!c.moveToFirst()){c.close();throw new RuntimeException("ไม่พบสินค้า");}
                double price=c.getDouble(0), stock=c.getDouble(1);c.close();
                if(stock<e.getValue()) throw new RuntimeException("สินค้าในสต็อกไม่เพียงพอ");
                total+=price*e.getValue();
            }
            String invoice="INV-"+System.currentTimeMillis();
            ContentValues s=new ContentValues();s.put("invoice",invoice);s.put("subtotal",total);s.put("total",total);s.put("payment_method",method);s.put("paid",paid);s.put("change_amount",Math.max(0,paid-total));
            long sid=db.insertOrThrow("sales",null,s);
            for(Map.Entry<Long,Integer> e:cart.entrySet()){
                Cursor c=db.rawQuery("SELECT name,cost,price FROM products WHERE id=?",new String[]{String.valueOf(e.getKey())});c.moveToFirst();
                String name=c.getString(0);double cost=c.getDouble(1),price=c.getDouble(2);c.close();
                int qty=e.getValue();ContentValues it=new ContentValues();it.put("sale_id",sid);it.put("product_id",e.getKey());it.put("product_name",name);it.put("qty",qty);it.put("cost",cost);it.put("price",price);it.put("line_total",price*qty);db.insertOrThrow("sale_items",null,it);
                db.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{qty,e.getKey()});movement(db,e.getKey(),"SALE",-qty,"ขายสินค้า "+invoice);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }
    public Cursor sales() { return getReadableDatabase().rawQuery("SELECT invoice,created_at,total,payment_method FROM sales ORDER BY id DESC",null); }
    public Cursor inventorySummary() {
        return getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(stock),0),COALESCE(SUM(stock*cost),0),COALESCE(SUM(stock*price),0) FROM products WHERE active=1",null);
    }
    public Cursor topProducts() {
        return getReadableDatabase().rawQuery("SELECT product_name,SUM(qty),SUM(line_total) FROM sale_items GROUP BY product_id ORDER BY SUM(qty) DESC LIMIT 5",null);
    }
}
