package com.myshop.pos;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.database.Cursor;
import java.util.*;

public class MainActivity extends Activity {
    DatabaseHelper db;
    LinearLayout root, content, nav;
    Map<Long,Integer> cart=new LinkedHashMap<>();
    TextView cartTotal;
    EditText search;
    int green=Color.rgb(139,213,139), dark=Color.rgb(32,91,48), pale=Color.rgb(229,250,226);
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);show("ขาย");}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(12,10,12,10);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void show(String tab){
        root=column();root.setBackgroundColor(Color.rgb(247,248,247));setContentView(root);
        TextView head=text("MyShop POS  •  "+tab,22,dark);head.setTypeface(null,1);head.setBackgroundColor(green);root.addView(head);
        content=column();ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(Color.WHITE);
        String[] tabs={"ขาย","สต็อก","ประวัติ","รายงาน","เพิ่มเติม"};
        for(String x:tabs){TextView b=text(x,13,x.equals(tab)?dark:Color.DKGRAY);b.setGravity(Gravity.CENTER);b.setOnClickListener(v->show(x));nav.addView(b,new LinearLayout.LayoutParams(0,58,1));}
        root.addView(nav);
        if(tab.equals("ขาย")) saleScreen();
        else if(tab.equals("สต็อก")) stockScreen();
        else if(tab.equals("ประวัติ")) historyScreen();
        else if(tab.equals("รายงาน")) reportScreen();
        else moreScreen();
    }
    void saleScreen(){
        search=new EditText(this);search.setSingleLine();search.setHint("ค้นหาชื่อสินค้า / SKU / บาร์โค้ด");content.addView(search);
        LinearLayout products=column();content.addView(products);
        Runnable refresh=()->{products.removeAllViews();Cursor c=db.products(search.getText().toString());while(c.moveToNext()){
            long id=c.getLong(0);String name=c.getString(1),unit=c.getString(4);double price=c.getDouble(6),stock=c.getDouble(7);
            TextView p=text(name+"   ฿"+money(price)+"\nคงเหลือ "+stock+" "+unit,16,dark);p.setBackgroundColor(Color.WHITE);p.setPadding(18,18,18,18);
            p.setOnClickListener(v->{cart.put(id,cart.getOrDefault(id,0)+1);refreshCart.setText(cartLabel());});products.addView(p);
        }c.close();};
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(Editable e){}});
        refresh.run();
        TextView cartTitle=text("ตะกร้าสินค้า",19,dark);content.addView(cartTitle);
        TextView refreshCart=text(cartLabel(),16,dark);refreshCart.setBackgroundColor(pale);content.addView(refreshCart);
        Button pay=new Button(this);pay.setText("ชำระเงิน");pay.setOnClickListener(v->paymentDialog());content.addView(pay);
    }
    TextView refreshCart;
    String cartLabel(){double sum=0;StringBuilder s=new StringBuilder();for(Map.Entry<Long,Integer> e:cart.entrySet()){Cursor c=db.products("");while(c.moveToNext())if(c.getLong(0)==e.getKey()){double line=c.getDouble(6)*e.getValue();sum+=line;s.append(c.getString(1)).append(" × ").append(e.getValue()).append("   ฿").append(money(line)).append("\\n");}c.close();}return s+"\\nรวม ฿"+money(sum);}
    double cartSum(){double sum=0;for(Map.Entry<Long,Integer> e:cart.entrySet()){Cursor c=db.products("");while(c.moveToNext())if(c.getLong(0)==e.getKey())sum+=c.getDouble(6)*e.getValue();c.close();}return sum;}
    void paymentDialog(){
        if(cart.isEmpty()){toast("กรุณาเลือกสินค้าก่อน");return;}
        String[] methods={"เงินสด","เงินโอน"};
        new AlertDialog.Builder(this).setTitle("เลือกวิธีชำระเงิน").setItems(methods,(d,w)->{
            double total=cartSum();
            if(w==1){try{db.checkout(cart,"เงินโอน",total);cart.clear();show("ขาย");toast("บันทึกการขายแล้ว");}catch(Exception e){toast(e.getMessage());}}
            else {
                EditText amount=new EditText(this);amount.setInputType(8194);amount.setHint("รับเงิน (ยอดรวม ฿"+money(total)+")");
                new AlertDialog.Builder(this).setTitle("รับเงินสด").setView(amount).setNegativeButton("ยกเลิก",null).setPositiveButton("ยืนยัน",(x,y)->{
                    try{double paid=Double.parseDouble(amount.getText().toString());if(paid<total){toast("จำนวนเงินไม่พอ");return;}db.checkout(cart,"เงินสด",paid);cart.clear();show("ขาย");toast("บันทึกการขายแล้ว");}catch(Exception e){toast("กรุณากรอกจำนวนเงินให้ถูกต้อง");}
                }).show();
            }
        }).show();
    }
    void stockScreen(){
        Button add=new Button(this);add.setText("+ เพิ่มสินค้า");add.setOnClickListener(v->addProductDialog());content.addView(add);
        Cursor c=db.products("");while(c.moveToNext()){
            TextView t=text(c.getString(1)+"\\nทุน ฿"+money(c.getDouble(5))+"  |  ขาย ฿"+money(c.getDouble(6))+"\\nคงเหลือ "+c.getDouble(7)+" "+c.getString(4),16,dark);t.setBackgroundColor(Color.WHITE);content.addView(t);
        }c.close();
    }
    void addProductDialog(){
        LinearLayout box=column();EditText name=new EditText(this);name.setHint("ชื่อสินค้า *");box.addView(name);
        EditText sku=new EditText(this);sku.setHint("SKU");box.addView(sku);
        EditText barcode=new EditText(this);barcode.setHint("บาร์โค้ด");box.addView(barcode);
        EditText cat=new EditText(this);cat.setHint("หมวดหมู่ เช่น เครื่องดื่ม");box.addView(cat);
        EditText unit=new EditText(this);unit.setHint("หน่วย เช่น ขวด / ชิ้น");box.addView(unit);
        EditText cost=new EditText(this);cost.setHint("ราคาทุน (บาท)");cost.setInputType(8194);box.addView(cost);
        EditText price=new EditText(this);price.setHint("ราคาขาย (บาท)");price.setInputType(8194);box.addView(price);
        EditText stock=new EditText(this);stock.setHint("จำนวนเริ่มต้น");stock.setInputType(8194);box.addView(stock);
        ScrollView sv=new ScrollView(this);sv.addView(box);
        new AlertDialog.Builder(this).setTitle("เพิ่มสินค้า").setView(sv).setNegativeButton("ยกเลิก",null).setPositiveButton("บันทึก",(d,w)->{
            try{if(name.getText().toString().trim().isEmpty())throw new Exception();db.addProduct(sku.getText().toString(),barcode.getText().toString(),name.getText().toString(),cat.getText().toString().isEmpty()?"อื่น ๆ":cat.getText().toString(),unit.getText().toString().isEmpty()?"ชิ้น":unit.getText().toString(),num(cost),num(price),num(stock));show("สต็อก");}
            catch(Exception e){toast("กรุณาตรวจสอบชื่อสินค้าและตัวเลข");}
        }).show();
    }
    double num(EditText e){return e.getText().toString().isEmpty()?0:Double.parseDouble(e.getText().toString());}
    void historyScreen(){Cursor c=db.sales();if(c.getCount()==0)content.addView(text("ยังไม่มีประวัติการขาย",16,Color.GRAY));while(c.moveToNext())content.addView(text(c.getString(0)+"\\n"+c.getString(1)+"\\n"+c.getString(2)+"  •  "+c.getString(3),15,dark));c.close();}
    void reportScreen(){
        Cursor c=db.inventorySummary();if(c.moveToFirst()){
            content.addView(text("รายงานสินค้าคงเหลือ",20,dark));
            content.addView(text("จำนวนรายการสินค้า: "+c.getInt(0),16,dark));
            content.addView(text("จำนวนคงเหลือรวม: "+c.getDouble(1),16,dark));
            TextView cost=text("มูลค่าตามราคาทุน\\n฿"+money(c.getDouble(2)),22,dark);cost.setBackgroundColor(pale);content.addView(cost);
            TextView retail=text("มูลค่าตามราคาขาย\\n฿"+money(c.getDouble(3)),22,dark);retail.setBackgroundColor(Color.WHITE);content.addView(retail);
            content.addView(text("กำไรขั้นต้นคาดการณ์\\n฿"+money(c.getDouble(3)-c.getDouble(2)),18,dark));
        }c.close();
        content.addView(text("สินค้าขายดี",20,dark));Cursor top=db.topProducts();while(top.moveToNext())content.addView(text(top.getString(0)+"  •  "+top.getDouble(1)+" ชิ้น  •  ฿"+money(top.getDouble(2)),15,dark));top.close();
    }
    void moreScreen(){content.addView(text("ตั้งค่าและสำรองข้อมูล",20,dark));content.addView(text("เวอร์ชันเริ่มต้น: ข้อมูลเก็บในโทรศัพท์แบบออฟไลน์\\nการส่งออก/กู้คืนไฟล์และ Google Drive จะพัฒนาในขั้นถัดไป",16,dark));}
    String money(double n){return String.format(java.util.Locale.US,"%,.2f",n);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
